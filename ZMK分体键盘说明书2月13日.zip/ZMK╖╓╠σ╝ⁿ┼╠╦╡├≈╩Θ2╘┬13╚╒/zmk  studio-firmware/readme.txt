https://zmk.studio/
 if you want to use ZMK STUDIO，you must  update the firmware.
the zmk studio  has 2 version ，web version and exe version.They have the same function, just use any one of them.