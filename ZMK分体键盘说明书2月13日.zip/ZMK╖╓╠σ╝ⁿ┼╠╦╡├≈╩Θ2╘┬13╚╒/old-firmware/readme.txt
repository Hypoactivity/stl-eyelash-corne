刷固件之前需要确认您购买的是哪款键盘，不同键盘使用的固件不同。使用的代码仓库也不同。此文件夹内的固件都不支持studio本地改建软件，故而停用。

Before flashing the firmware, you need to confirm which keyboard you have purchased. Different keyboards use different firmware. They also use different code repositories.The firmware in  this file do not support ZMK SUTIO. So don't use it anymore, just for archival backup.